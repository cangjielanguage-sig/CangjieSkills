# 声明式UI描述

<!--Del-->
> **说明：**
>
> 当前为Beta阶段。
<!--DelEnd-->

仓颉编程语言以声明方式组合和扩展组件来描述应用程序的UI，同时还提供了基本的属性、事件和子组件配置方法，帮助开发者实现应用交互逻辑。

## 构建组件

根据组件构造方法的不同，创建组件包含有参数和无参数两种方式。

### 无参数

如果组件的接口定义没有包含必选构造参数，则组件后面的“()”不需要配置任何内容。例如，Divider组件不包含构造参数。

 <!-- run-->

```cangjie
package ohos_app_cangjie_entry

import kit.ArkUI.*
import ohos.arkui.state_macro_manage.*

@Entry
@Component
class EntryView {
    func build() {
        Column() {
            Text("item 1")
            Divider()
            Text("item 2")
        }
    }
}
```

### 有参数

如果组件的接口定义包含构造参数，则在组件后面的“()”需要配置相应参数。

- Image组件的必选参数src。

  ```cangjie
  Image("https://xyz/test.jpg")
  ```

- Text组件的非必选参数content。

  ```cangjie
  // string类型的参数
  Text("test")
  // @r形式引入应用资源，可应用于多语言场景
  Text(@r(app.string.title_value))
  // 无参数形式
  Text() {}
  ```

- 变量或表达式也可以用于参数赋值，其中表达式返回的结果类型必须满足参数类型要求。

  例如，设置变量或表达式来构造Image和Text组件的参数。

  ```cangjie
  Image(this.imagePath)
  Image("https://" + this.imageUrl)
  Text("count: ${this.count}")
  ```

## 配置属性

属性方法以“.”链式调用的方式配置系统组件的样式和其他属性，建议每个属性方法单独写一行。

- 配置Text组件的字体大小。

  ```cangjie
  Text("test")
    .fontSize(12)
  ```

- 配置组件的多个属性。

  ```cangjie
  Image("test.jpg")
    .alt("error.jpg")
    .width(100)
    .height(100)
  ```

- 除了直接传递常量参数外，还可以传递变量或表达式。

  ```cangjie
  Text("hello")
    .fontSize(this.size)
  Image("test.jpg")
    .width(if(this.count % 2 == 0) {100} else {200})
    .height(this.offset + 100)
  ```

- 对于系统组件，仓颉编程语言还为其属性预定义了一些枚举类型供开发者调用，枚举类型可以作为参数传递，但必须满足参数类型要求。

  例如，可以按以下方式配置Text组件的颜色和字体样式。

  ```cangjie
  Text("hello")
    .fontSize(20)
    .fontColor(Color.Red)
    .fontWeight(FontWeight.Bold)
  ```

## 配置事件

事件方法以“.”链式调用的方式配置系统组件支持的事件，建议每个事件方法单独写一行。

- 使用箭头函数配置组件的事件方法。

  ```cangjie
  Button("Click me")
  .onClick({ evt =>
    this.myText = "Cangjie"
  })
  ```

- 使用箭头函数表达式配置组件的事件方法，要求使用“{ => ...}”，以确保函数与组件绑定，同时符合仓颉编程语言语法规范。

  ```cangjie
  Button("add counter")
    .onClick({evt =>
      this.counter += 2
    })
  ```

- 使用声明的Lambda表达式，可以直接调用。

  ```cangjie
  var fn: (ClickEvent) -> Unit = {evt =>}
  protected func aboutToAppear() {
      fn = {evt =>
          this.counter++
      }
  }
  ...
  Button("add counter")
    .onClick(fn)
  ```

> **说明：**
>
> 箭头函数内部的this是词法作用域，由上下文确定。匿名函数可能会有this指向不明确问题，在仓颉编程语言中不允许使用。

## 配置子组件

如果组件支持子组件配置，则需在尾随闭包"{...}"中为组件添加子组件的UI描述。Column、Row、Stack、Grid、List等组件都是容器组件。

以下是简单的Column组件配置子组件的示例。

```cangjie
Column() {
  Text("Hello")
    .fontSize(100)
  Divider()
  Text(this.myText)
    .fontSize(100)
    .fontColor(Color.Red)
}
```

容器组件均支持子组件配置，可以实现相对复杂的多级嵌套。

```cangjie
Column() {
  Row() {
    Image("test1.jpg")
      .width(100)
      .height(100)
    Button("click +1")
      .onClick({evt =>
        Hilog.info(0, "cangjie", "+1 clicked!");
      })
  }
}
```
