# Stage模型应用配置文件

<!--Del-->
> **说明：**
>
> 当前为Beta阶段。
<!--DelEnd-->

应用配置文件中包含应用配置信息、应用组件信息、权限信息、开发者自定义信息等，这些信息在编译构建、分发和运行阶段分别提供给编译工具、应用市场和操作系统使用。

在基于Stage模型开发的应用项目代码下，都存在app.json5（一个）及module.json5（一个或多个）两种配置文件，常用配置项请参见[应用/组件级配置](cj-application-component-configuration-stage.md)。对于这两种配置文件的更多介绍，请参见[应用配置文件概述（Stage模型）](../cj-start/basic-knowledge/cj-application-configuration-file-overview-stage.md)。
