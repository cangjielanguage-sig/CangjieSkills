# 渲染控制概述

<!--Del-->
> **说明：**
>
> 当前为Beta阶段。
<!--DelEnd-->

ArkUI通过[自定义组件](../paradigm/cj-create-custom-components.md)的build()函数和[@Builder宏](../paradigm/cj-macro-builder.md)中的声明式UI描述语句构建相应的UI。在声明式描述语句中开发者除了使用系统组件外，还可以使用渲染控制语句来辅助UI的构建，这些渲染控制语句包括控制组件是否显示的条件渲染语句，基于数组数据快速生成组件的循环渲染语句，针对大数据量场景的数据懒加载语句，针对混合模式开发的组件渲染语句。
