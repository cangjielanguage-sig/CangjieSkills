# 应用程序包术语

<!--Del-->
> **说明：**
>
> 当前为Beta阶段。
<!--DelEnd-->

## E

### ExtensionAbility

Stage模型中的组件类型名，即ExtensionAbility组件，提供特定场景（如卡片、输入法）的扩展能力，满足更多的使用场景。

## H

### HAP

Harmony Ability Package，一个HAP文件包含应用的所有内容，由代码、资源、三方库及应用配置文件组成，其文件后缀名为.hap。

### HAR

Harmony Archive，静态共享包，编译态复用。可以包含代码、C++库、资源和配置文件，其文件后缀名为.har，用于实现代码和资源的共享。

### HSP

Harmony Shared Package，动态共享包，运行时复用。可以包含代码、C++库、资源和配置文件，其文件后缀名为.hsp，用于实现代码和资源的共享。

## M

### Module

模块，应用的一部分，每个模块都有单独的module.json5配置文件。项目工程中，Entry、Feature、HSP和HAR均为应用的一个模块。

## S

### Stage模型

API version 9开始新增的应用模型，提供UIAbility、ExtensionAbility两大类应用组件。由于该模型还提供了AbilityStage、WindowStage等类作为应用组件和Window窗口的“舞台”，因此称之为Stage模型。

## U

### UIAbility

Stage模型中的组件类型名，即UIAbility组件，包含UI，提供展示UI的能力，主要用于和用户交互。
